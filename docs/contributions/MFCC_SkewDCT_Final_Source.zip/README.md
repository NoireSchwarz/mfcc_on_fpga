# mfcc_on_fpga

## Recursive SkewDCT8 branch

The [module-by-module comparison with the original Mel Filter Bank](docs/contributions/Module_Comparison.md) lists the final branch's 26 functional groups across pre-processing, power spectrum, Mel/log, DCT and output. It identifies original IP cores, custom RTL additions, adapted upstream stages and the optional MatrixDCT reference. [Excel table](docs/contributions/Module_Comparison.xlsx) and [final RTL source bundle](docs/contributions/MFCC_SkewDCT_Final_Source.zip).

The shared SkewDCT8 now uses a registered 8-to-4-to-2 factorization for the project's eight coefficient families. Recursive mode receives a three-bit family ID directly; original parameter declarations and generic dense modes remain available. The recursive transform expresses 12 real products and 29 add/subtract operations, with multiplication, rounding and sparse post-adds separated by registers. This arithmetic count is not a measured DSP count.

The current RTL also pipelines C64 output processing into registered selection, compensation-product and post-add/output stages. It preserves output coefficients and adds three no-stall clocks. [C64 implementation and validation](docs/C64_Output_Pipeline.md) records the change.

Latest supplied measurements, tested commit **b0db7a0**: N=1024, STRIDE=512, OUT_WIDTH=64, **150 MHz default OOC post-route** on K26 / Vivado 2026.1:

| Resource scope | LUT | FF | BRAM tiles | DSP |
| --- | ---: | ---: | ---: | ---: |
| Complete MFCC | **35,777** | **53,107** | **6.5** | **59** |
| DCT64 hierarchy, included above | 6,041 | 12,125 | 0 | 41 |
| C64 output processing, included above | 1,107 | 1,706 | 0 | 1 |

**150 MHz passes: WNS=+0.258 ns, WHS=+0.010 ns, zero setup/hold failures**, without Explore or implementation retries. Against the pre-C64 recursive implementation at the same 150 MHz constraint, whole-MFCC resources increase by **120 LUT and 201 FF**; DSP and BRAM are unchanged. The four-frame RTL test takes 39,508 cycles, equivalent to 263.387 us at 150 MHz; this is a cycle conversion, not board latency.

**200 MHz has not been tested.** The current worst paths are filter-bank acknowledgement/frame-clear fanout and input-selection/Hamming multiplication. Freezing the present route gives an estimated -1.409 ns worst slack at 200 MHz; further optimization and a new implementation are required to assess closure. See the [verified reports, matched resource comparison and 200 MHz assessment](docs/benchmarks/c64_pipeline_N1024_150MHz_20261026/README.md).

### Consolidated benchmarks

The supplied **2026-10-27, 50 MHz** summaries now fill the register-MatrixDCT hardware results. Standalone 64-point DCT resources:

| Backend | LUT | FF | BRAM tiles | DSP | Final-output cycles |
| --- | ---: | ---: | ---: | ---: | ---: |
| Register MatrixDCT | **1,847** | **2,717** | **0** | **1** | 4,352 |
| Recursive SkewDCT | **5,113** | **12,378** | **0** | **41** | 238 |

Whole MFCC with MatrixDCT uses **30,110 LUT, 43,473 FF, 6.5 BRAM tiles and 19 DSP**, with reported WNS **+8.235 ns** at 50 MHz. Its N1024 four-frame test takes 43,622 cycles, versus 39,508 for SkewDCT. Standalone counts are separate from MFCC hierarchy counts. Both standalone DCTs report zero BRAM, while multiplier parallelism remains different. These are supplied OOC post-route summaries; original Vivado reports were not included. [Source, checks and comparison](docs/benchmarks/matrix_register_50MHz_20261027/README.md).

All six supplied benchmark packages and the two latest result summaries are classified in the [benchmark catalog](docs/benchmarks/README.md): [complete MFCC](docs/benchmarks/full_mfcc/README.md), [FFT/XFFT](docs/benchmarks/fft/README.md), [DCT comparison](docs/benchmarks/dct/README.md) and [memory optimization](docs/benchmarks/memory/README.md).

The [14-sheet Excel workbook](docs/benchmarks/MFCC_Benchmark_Summary.xlsx) and [consolidated JSON](docs/benchmarks/combined_data.json) keep the latest valid metric for each test/configuration, including a separate standalone-DCT sheet. Architecture and pipeline generations are not separate primary result rows. LUT, FF, BRAM and DSP appear first; per-metric source columns retain provenance. Earlier reports remain available as evidence without repeating superseded values in the main tables.

See the [implementation notes](docs/SkewDCT8_Recursive.md) and [architecture PDF](Architecture/SkewDCT8_Recursive/SkewDCT8_Recursive_Architecture.pdf) for the current datapath.

### DCT-Modul

Das Design des DCT-Moduls orientiert sich an den folgenden Publikationen [^1] [^2].

---

## Referenzen / References

[^1]: Markus Püschel. *Cooley-Tukey FFT Like Algorithms for the DCT*. Department of Electrical and Computer Engineering, Carnegie Mellon University. [📄 PDF](https://spiral.ece.cmu.edu/pub-smart/pubfile/paper_16.pdf)
[^2]: Markus Püschel and José M. F. Moura. *Algebraic Signal Processing Theory: Cooley-Tukey Type Algorithms for DCTs and DSTs*. [📄 PDF](https://spiral.ece.cmu.edu/pub-spiral/pubfile/asp-dct_150.pdf)


## Upload log

### 2026-11-20 - Document module contributions and publish the final RTL snapshot

- Compared the final SkewDCT branch with the original `lxschwalb/fpga_mel_filter_bank` commit `0148cd8`, using 26 functional groups and five processing stages. Kept remarks in the rightmost column and explicitly identified vendor IP, rewritten stages and integrated/adapted arithmetic.
- Documented the eight FFT lengths, including 16/32, with the AMD Radix-4-specific size restriction stated accurately. Recorded the sparse 64-band Mel lookup, wide energy accumulation and fractional logarithm pipeline changes.
- Added an English Markdown/CSV/Excel table, complete RTL/coefficient hash inventory and a deterministic final source bundle. Retained the upstream MIT notice. Production RTL and the existing vendor IP directory are unchanged.

### 2026-10-27 - Import 50 MHz register-MatrixDCT and standalone-DCT results

- Replaced pending MatrixDCT resource/timing fields with the supplied results for commit `0dce6b0`; retained existing SkewDCT whole-MFCC implementation measurements where no new measurement was supplied.
- Added standalone MatrixDCT/SkewDCT resources and first/final latency in a separate CSV and workbook sheet. Whole-MFCC and inclusive hierarchy counts remain separate scopes.
- Crosschecked CSV/JSON values, cycle conversions and ratios; retained both original files with SHA-256 hashes. Corrected the derived FF-reduction percentage in analysis using the supplied counts, while preserving the original JSON.
- Updated resource-first tables, the 14-sheet workbook and consolidated JSON. Hardware values are supplied OOC post-route summaries; original implementation reports were not included. RTL is unchanged.

### 2026-10-26 - Replace MatrixDCT BRAM storage with FF/LUT storage

- Captured the input frame in parallel FFs, used a LUT coefficient ROM and separate output-register words, and retained the public MatrixDCT interface and numerical parameters.
- Kept operand selection, multiplication and accumulation in separate register stages. Removed BRAM-only input loading and output-read preparation; standalone completion changes from 4,417 to 4,352 clocks.
- Passed six unit parameter cases against the original RTL and an independent integer model, plus twenty complete-MFCC configurations with zero coefficient differences. The N1024 unstalled four-frame batch changes from 43,687 to 43,622 clocks.
- Marked current MatrixDCT resource/timing values pending in the catalog; old BRAM measurements are not assigned to the new implementation. New synthesis, physical RAM mapping and timing remain to be measured.

### 2026-10-26 - Consolidate benchmark results by test project

- Classified all six supplied benchmark packages into complete-MFCC, FFT/XFFT, DCT and memory-optimization results, with a common index, 13-sheet workbook, CSV tables and JSON.
- Kept the latest valid metric for each test/configuration; architecture and pipeline generations no longer create repeated primary result rows. Different frequencies, point counts and comparison backends remain explicit.
- Retained per-metric evidence sources, original report bytes and archive hashes. Updated the SkewDCT/MatrixDCT comparison and N1024 runtime to the latest matching results.
- Preserved the explicit paired memory before/after experiment. The interrupted legacy 200 MHz attempt is not counted as a pass or fail; the latest 200 MHz value remains an estimate. No RTL or hardware test was changed.

### 2026-10-26 - Verify C64 pipeline at 150 MHz

- Imported the supplied b0db7a0 results; verified all 16 archive checksums, four core RTL snapshots and the RTL source-list hash.
- Recorded a default 150 MHz OOC post-route timing pass: WNS +0.258 ns, WHS +0.010 ns, no setup or hold failures. Complete MFCC uses 35,777 LUT, 53,107 FF, 6.5 BRAM tiles and 59 DSP.
- Added a matched 150 MHz before/after comparison, raw reports and independently checked numerical results. The four-frame regression takes 39,508 cycles and preserves the pre-C64 coefficient CSV.
- Classified the 20 reported worst setup paths and documented an explicitly estimated 200 MHz margin. No production RTL was changed or hardware run performed during this results import; 200 MHz remains untested.

### 2026-10-26 - Pipeline C64 output processing

- Registered indexed operand selection, sqrt(2) compensation and post-add/output in three stages, carrying index, validity and bypass controls with the data.
- Preserved the original truncating arithmetic and interface. Backpressure and ED hold the complete pipeline; completion follows acceptance of the final output.
- Passed ten C64 parameter configurations, complete-DCT64 checks, twenty MFCC configurations and two 459-frame audio regressions with zero coefficient differences. The N1024 unstalled four-frame batch changes from 39,505 to 39,508 cycles.
- Replaced the existing C64 and DCT64 overview figures and updated the combined architecture PDF. Follow-up Vivado measurements are recorded in the subsequent results import above.

### 2026-10-26 - Recursive SkewDCT measurements

- Imported the supplied N1024 benchmark package, verified all 35 packaged checksums and checked the included core sources against tested commit 8f1fd37.
- Added raw post-route reports, verified CSV/JSON results and a resource comparison. Complete-MFCC DSP use falls from 123 to 59; LUT and FF use rise to 35,601 and 52,870 at 50 MHz.
- Recorded 50/100 MHz timing passes and the 150 MHz setup failure. Classified the 20 reported worst setup paths as C64 selection/multiplication/post-add and MFCC writeback; the former dense 150 MHz signoff used an additional Explore step.
- Independently recomputed precision metrics from local coefficient CSVs whose hashes match the package. This update changes reports and documentation only.

### 2026-10-25 - Narrow SkewDCT8 family interface

- Reduced recursive-mode c_in from 64*COEF_W bits (1,280 bits in the production wrapper) to a three-bit BLOCK family ID.
- Removed the Skew matrix coefficient ROM, wide coefficient interconnect and signature decoder from the production path. Generic matrix modes retain their original interface widths.
- Kept the thirteen-stage arithmetic, precision, valid/tag protocol and enabled-edge latency unchanged. Verified exact outputs against the preceding recursive implementation, including complete-MFCC runs without the old matrix ROM file.
- Updated the core and TDM-bank diagrams and the combined PDF; aligned the output assignments and connected their ports in the bank figure. Physical routing and utilization savings still require Vivado measurement.
- Connected the DCT64 overview's input/output handshake and overflow-status ports, replacing detached labels with routed connections and the existing sticky status registers.


### 2026-10-25 - Recursive SkewDCT8 pipeline

- Replaced the active dense SkewDCT8 calculation with an 8-to-4-to-2 factorization and 13 enabled register stages, retaining an initiation interval of one enabled edge.
- Kept the existing core ports and original parameter list, preserving the six-stage generic dense modes and selecting the structured path in the existing TDM wrapper.
- Verified the core, TDM bank, DCT64, 20 complete-MFCC configurations and two 459-frame audio runs. Recursive arithmetic uses a different rounding order; observed full-audio differences from the dense baseline were at most four output integer units.
- Updated the SkewDCT8, TDM-bank and DCT64 diagrams and added a five-page PDF with PNG/SVG exports. Hardware resource and post-route timing measurements remain pending.


### 2026-10-25 — High-frequency optimization

- Optimized the critical FFT and DCT datapaths by registering multiplication, addition/subtraction, reduction, and rounding stages to shorten combinational paths.
- Reorganized FFT intermediate storage and read/write scheduling around synchronous dual-port BRAM, reducing large register arrays and wide selection logic.
- Refined fixed-point widths, scaling, and rounding to improve numerical precision while retaining 64-dimensional MFCC output.
- Completed RTL functional simulations for FFT lengths 16/32/64/128/256/512/1024/2048, DCT, and the complete MFCC pipeline. Coefficient comparisons with the corresponding frozen references found no differences.
